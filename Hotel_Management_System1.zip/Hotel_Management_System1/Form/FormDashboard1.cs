﻿using Hotel_Management_System1.Reports;
using Hotel_Management_System1.User_Control;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hotel_Management_System1
{
    public partial class FormDashboard1 : Form
    {
        public string UserName2;
        public FormDashboard1()
        {
            InitializeComponent();
        }
        
        private void MovePanel(Control btn)
        {
            panelSlide.Top = btn.Top;
            panelSlide.Height = btn.Height;
        }
        private void LinkLabelLogOut_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            DialogResult result = MessageBox.Show("Do you want to log out?", "Logout", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if(DialogResult.Yes == result)
            { 
                timer1.Stop();
                this.Close();
            }
        }

        private void LabelDateTime_Click(object sender, EventArgs e)
        {

        }

        private void Timer1_Tick(object sender, EventArgs e)
        {
            labelDateTime.Text = DateTime.Now.ToString("dd-MMMM-yyyy hh:mm:ss tt");
        }

        private void FormDashboard_Load(object sender, EventArgs e)
        {
            timer1.Start();
            labelUserName2.Text = UserName2;
            
        }



        private void ButtonDashboard_Click(object sender, EventArgs e)
        {
            MovePanel(buttonDashboard);
            userControlSettings211.Hide();
            userControlClient2.Hide(); 
            userControlRoom1.Hide();
            userControlReservation1.Hide();
            userControlDashboard1.User();
            userControlDashboard1.Client();
            userControlDashboard1.Room();
            userControlDashboard1.Show();

        }

        private void ButtonClient_Click(object sender, EventArgs e)
        {
            MovePanel(buttonClient);
            userControlSettings211.Hide();
            userControlClient2.clear();
            userControlClient2.Show();
            userControlRoom1.Hide();
            userControlReservation1.Hide();
            userControlDashboard1.Hide();
        }

        private void ButtonRoom_Click(object sender, EventArgs e)
        {
            MovePanel(buttonRoom);
            userControlSettings211.Hide();
            userControlClient2.Hide();
            userControlRoom1.clear();
            userControlRoom1.Show();
            userControlReservation1.Hide();
            userControlDashboard1.Hide();
        }

        private void ButtonReservation_Click(object sender, EventArgs e)
        {
            MovePanel(buttonReservation);
            userControlSettings211.Hide();
            userControlClient2.Hide();
            userControlRoom1.Hide();
            //userControlReservation1.Clear();
            userControlReservation1.Show();
            userControlDashboard1.Hide();
        }

        private void ButtonSettings_Click(object sender, EventArgs e)
        {
            MovePanel(buttonSettings);
            userControlSettings211.Clear();
            userControlSettings211.Show();
            userControlClient2.Hide();
            userControlRoom1.Hide();
            userControlReservation1.Show();
            userControlDashboard1.Hide();

        }

        private void PanelSlide_Paint(object sender, PaintEventArgs e)
        {

        }

        private void UserControlRoom1_Load(object sender, EventArgs e)
        {

        }

        private void LabelUsername_Click(object sender, EventArgs e)
        {

        }

        private void UserControlReservation1_Load(object sender, EventArgs e)
        {

        }

        private void buttonProducts_Click(object sender, EventArgs e)
        {
            FrmProducts products = new FrmProducts();
            products.Show();
        }
    }
}
