﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AMRConnector;

namespace Hotel_Management_System1.User_Control
{
    public partial class UserControlClient : UserControl
    {
        DbConnector db;
        private string ID = ""; 

        public UserControlClient()
        {
            InitializeComponent();
            db = new DbConnector();
        }

        public void clear()
        {
            textBoxFirstName.Clear();
            textBoxLastName.Clear();
            textBoxPhoneNumber.Clear();
            textBoxAddress.Clear();
            tabControlClient.SelectedTab = tabPageAddClient;
        }

        public void clear1()
        {
            textBoxFirstName1.Clear();
            textBoxLastName1.Clear();
            textBoxPhoneNumber1.Clear();
            textBoxAddress1.Clear();
            ID = "";
        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
            bool check;
            if (textBoxFirstName.Text.Trim() == string.Empty || textBoxLastName.Text.Trim() == string.Empty || textBoxPhoneNumber.Text.Trim() == string.Empty || textBoxAddress.Text.Trim() == string.Empty)
                MessageBox.Show("Please fill out all fields.", "Require all fields.", MessageBoxButtons.OK, MessageBoxIcon.Information);
            else
            {
                check = db.AddClient(textBoxFirstName.Text.Trim(), textBoxLastName.Text.Trim(), textBoxPhoneNumber.Text.Trim(), textBoxAddress.Text.Trim());
                if (check)
                    clear();
            }
        }

        private void tabPageAddClient_Leave(object sender, EventArgs e)
        {
            clear();
            clear1();
        }

        private void tabPageAddClient_Enter(object sender, EventArgs e)
        {

        }

        private void tabPageSearchClient_Enter(object sender, EventArgs e)
        {
            db.DisplayAndSearch("SELECT * FROM Client_Table", dataGridViewClient);
        }

        private void tabPageSearchClient_Leave(object sender, EventArgs e)
        {
            textBoxPhoneNumber.Clear();
        }

        private void textBoxSearchPhoneNumber_TextChanged(object sender, EventArgs e)
        {
            db.DisplayAndSearch("SELECT * FROM Client_Table WHERE Client_FirstName LIKE '%" + textBoxSearchPhoneNumber.Text + "%'", dataGridViewClient);
        }

        private void buttonUpdate1_Click(object sender, EventArgs e)
        {
            bool check;
            if (ID != "")
            {
                if (textBoxFirstName1.Text.Trim() == string.Empty || textBoxLastName1.Text.Trim() == string.Empty || textBoxPhoneNumber1.Text.Trim() == string.Empty || textBoxAddress1.Text.Trim() == string.Empty)
                    MessageBox.Show("Please Fill out all fields.", "Required all field.", MessageBoxButtons.OK, MessageBoxIcon.Information);
                else
                {
                    check = db.UpdateClient(ID, textBoxFirstName1.Text.Trim(), textBoxLastName1.Text.Trim(), textBoxPhoneNumber1.Text.Trim(), textBoxAddress1.Text.Trim());
                    if (check)
                        clear1();
                }
            }
            else MessageBox.Show("Please first select row from table.", "Selection of row.", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void buttonDelete_Click(object sender, EventArgs e)
        {          
                bool check;
                if (ID != "")
                {
                if (textBoxFirstName1.Text.Trim() == string.Empty || textBoxLastName1.Text.Trim() == string.Empty || textBoxPhoneNumber1.Text.Trim() == string.Empty || textBoxAddress1.Text.Trim() == string.Empty)
                        MessageBox.Show("Please Fill out all fields.", "Required all field.", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    else
                    {
                        DialogResult result = MessageBox.Show("Are you sure you want to delete this client?", "Client Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
                        if (DialogResult.Yes == result)
                        {
                            check = db.DeleteClient(ID);
                            if (check)
                                clear1();
                        }
                    }
                }
                else MessageBox.Show("Please first select row from table.", "Selection of row.", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void tabPageUpdateAndDeleteClient_Leave(object sender, EventArgs e)
        {
            clear1();
        }

        private void dataGridViewClient_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if(e.RowIndex != -1)
            {
                DataGridViewRow row = dataGridViewClient.Rows[e.RowIndex];
                ID = row.Cells[0].Value.ToString();
                textBoxFirstName1.Text = row.Cells[1].Value.ToString();
                textBoxLastName1.Text = row.Cells[2].Value.ToString();
                textBoxPhoneNumber1.Text = row.Cells[3].Value.ToString();
                textBoxAddress1.Text = row.Cells[4].Value.ToString();
            }
        }

        private void UserControlClient_Load(object sender, EventArgs e)
        {

        }

        private void dataGridViewClient_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void textBoxFirstName_TextChanged(object sender, EventArgs e)
        {

        }

        private void tabControlClient_Enter(object sender, EventArgs e)
        {
            db.DisplayAndSearch("SELECT * FROM Client_Table", dataGridViewClient);
        }

        private void tabPageAddClient_Click(object sender, EventArgs e)
        {

        }
    }
}
