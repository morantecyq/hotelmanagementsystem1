﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AMRConnector;

namespace Hotel_Management_System1.Reports
{
    public partial class FrmTransaction : Form
    {
        DbConnector db;
        public FrmTransaction()
        {
            InitializeComponent();
            db = new DbConnector();
        }
        private void FrmTransaction_Load(object sender, EventArgs e)
        {

        }
    }
}
