﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Util;
using System.Windows.Forms;
using Hotel_Management_System1.CrystalReport;
using AMRConnector;
namespace Hotel_Management_System1.Reports
{
    public partial class FrmProducts : Form
    {
        DbConnector db;
        //SqlConnection con = new SqlConnection("Data Source= DESKTOP-B9M7OG4\\SQLEXPRESS;" +
        //"Initial Catalog=MyDatabase;" +
        //"Integrated Security=True;" +
        // "Trusted_Connection=True");

        // SqlCommand cmd = new SqlCommand();
        //SqlDataReader reader;
        public FrmProducts()
        {
            InitializeComponent();
            db = new DbConnector();
        }

        private void FrmProducts_Load(object sender, EventArgs e)
        {
            Loadproduct();
        }

        private void Loadproduct()
        {
            //crProducts productReport = new crProducts();
            //con.Open();

            //cmd.CommandText = "select * from Products";
           // DataSet ds = new DataSet();
            //SqlDataAdapter adapater = new SqlDataAdapter(cmd.CommandText, con);

            //adapater.Fill(ds, "Product");
           // DataTable dt = ds.Tables["Products"];

            //productReport.SetDataSource(ds.Tables["Products"]);
           // FrmProducts.ReportSource = productReport;
            //FrmProducts.Refresh();
           // con.Close();
            

        }
    }
}
